<!DOCTYPE html>
<html lang="bs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteka MVC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">Biblioteka MVC</a>
        <div>
            <a class="btn btn-outline-light me-2" href="index.php?controller=book&action=index">Knjige</a>
            <a class="btn btn-outline-light" href="index.php?controller=category&action=index">Kategorije</a>
        </div>
    </div>
</nav>
<div class="container mt-4"></div>