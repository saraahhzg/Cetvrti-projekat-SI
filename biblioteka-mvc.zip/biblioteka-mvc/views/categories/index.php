<?php include "../views/layout/header.php"; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Lista kategorija</h2>
    <a href="index.php?controller=category&action=create" class="btn btn-primary">Dodaj kategoriju</a>
</div>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Naziv kategorije</th>
            <th>Akcije</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = $categories->fetch(PDO::FETCH_ASSOC)): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td>
                    <a href="index.php?controller=category&action=edit&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Izmijeni</a>
                    <a href="index.php?controller=category&action=delete&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm delete-btn">Obriši</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include "../views/layout/footer.php"; ?>