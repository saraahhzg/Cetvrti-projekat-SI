<?php include "../views/layout/header.php"; ?>

<h2>Dodaj kategoriju</h2>

<form method="POST">
    <div class="mb-3">
        <label class="form-label">Naziv kategorije</label>
        <input type="text" name="name" class="form-control" required>
    </div>

    <button type="submit" class="btn btn-success">Sačuvaj</button>
    <a href="index.php?controller=category&action=index" class="btn btn-secondary">Nazad</a>
</form>

<?php include "../views/layout/footer.php"; ?>