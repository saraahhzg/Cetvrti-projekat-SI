<?php include "../views/layout/header.php"; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Lista knjiga</h2>
    <a href="index.php?controller=book&action=create" class="btn btn-primary">Dodaj knjigu</a>
</div>

<input type="text" id="searchInput" class="form-control mb-3" placeholder="Pretraži knjige...">

<table class="table table-bordered table-striped" id="booksTable">
    <thead class="table-dark">
        <tr>
            <th>ID</th>
            <th>Naslov</th>
            <th>Autor</th>
            <th>Godina</th>
            <th>Kategorija</th>
            <th>Akcije</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = $books->fetch(PDO::FETCH_ASSOC)): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['title']; ?></td>
                <td><?php echo $row['author']; ?></td>
                <td><?php echo $row['year_published']; ?></td>
                <td><?php echo $row['category_name']; ?></td>
                <td>
                    <a href="index.php?controller=book&action=edit&id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Izmijeni</a>
                    <a href="index.php?controller=book&action=delete&id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm delete-btn">Obriši</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include "../views/layout/footer.php"; ?>