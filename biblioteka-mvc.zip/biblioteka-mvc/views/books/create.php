<?php include "../views/layout/header.php"; ?>

<h2>Dodaj novu knjigu</h2>

<form method="POST" id="bookForm">
    <div class="mb-3">
        <label class="form-label">Naslov</label>
        <input type="text" name="title" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Autor</label>
        <input type="text" name="author" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Godina izdavanja</label>
        <input type="number" name="year_published" class="form-control" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Kategorija</label>
        <select name="category_id" class="form-select" required>
            <option value="">Odaberi kategoriju</option>
            <?php while($cat = $categories->fetch(PDO::FETCH_ASSOC)): ?>
                <option value="<?php echo $cat['id']; ?>">
                    <?php echo $cat['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>

    <button type="submit" class="btn btn-success">Sačuvaj</button>
    <a href="index.php?controller=book&action=index" class="btn btn-secondary">Nazad</a>
</form>

<?php include "../views/layout/footer.php"; ?>