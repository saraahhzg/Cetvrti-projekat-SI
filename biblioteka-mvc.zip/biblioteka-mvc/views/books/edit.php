<?php include "../views/layout/header.php"; ?>

<h2>Izmijeni knjigu</h2>

<form method="POST" id="bookForm">
    <div class="mb-3">
        <label class="form-label">Naslov</label>
        <input type="text" name="title" class="form-control" value="<?php echo $book['title']; ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Autor</label>
        <input type="text" name="author" class="form-control" value="<?php echo $book['author']; ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Godina izdavanja</label>
        <input type="number" name="year_published" class="form-control" value="<?php echo $book['year_published']; ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Kategorija</label>
        <select name="category_id" class="form-select" required>
            <?php while($cat = $categories->fetch(PDO::FETCH_ASSOC)): ?>
                <option value="<?php echo $cat['id']; ?>" <?php if($cat['id'] == $book['category_id']) echo "selected"; ?>>
                    <?php echo $cat['name']; ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>

    <button type="submit" class="btn btn-success">Sačuvaj izmjene</button>
    <a href="index.php?controller=book&action=index" class="btn btn-secondary">Nazad</a>
</form>

<?php include "../views/layout/footer.php"; ?>