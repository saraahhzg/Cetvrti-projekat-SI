document.addEventListener("DOMContentLoaded", function () {
    let deleteButtons = document.querySelectorAll(".delete-btn");

    deleteButtons.forEach(function (button) {
        button.addEventListener("click", function (e) {
            if (!confirm("Da li ste sigurni da želite obrisati ovaj zapis?")) {
                e.preventDefault();
            }
        });
    });

    let searchInput = document.getElementById("searchInput");
    if (searchInput) {
        searchInput.addEventListener("keyup", function () {
            let filter = searchInput.value.toLowerCase();
            let rows = document.querySelectorAll("#booksTable tbody tr");

            rows.forEach(function (row) {
                let text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? "" : "none";
            });
        });
    }

    let bookForm = document.getElementById("bookForm");
    if (bookForm) {
        bookForm.addEventListener("submit", function (e) {
            let yearInput = document.querySelector("input[name='year_published']");
            let year = parseInt(yearInput.value);

            if (year < 0 || year > new Date().getFullYear()) {
                alert("Unesite ispravnu godinu izdavanja.");
                e.preventDefault();
            }
        });
    }
});