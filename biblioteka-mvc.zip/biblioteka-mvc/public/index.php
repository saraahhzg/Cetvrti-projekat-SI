<?php
$controller = isset($_GET['controller']) ? $_GET['controller'] : 'book';
$action = isset($_GET['action']) ? $_GET['action'] : 'index';

switch ($controller) {
    case 'book':
        require_once "../controllers/BookController.php";
        $controllerObj = new BookController();
        break;

    case 'category':
        require_once "../controllers/CategoryController.php";
        $controllerObj = new CategoryController();
        break;

    default:
        die("Nepostojeći controller.");
}

if (method_exists($controllerObj, $action)) {
    $controllerObj->$action();
} else {
    die("Nepostojeća akcija.");
}
?>