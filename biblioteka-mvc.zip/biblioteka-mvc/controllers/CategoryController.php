<?php
require_once "../config/Database.php";
require_once "../models/Category.php";

class CategoryController {
    private $model;

    public function __construct() {
        $database = new Database();
        $db = $database->connect();
        $this->model = new Category($db);
    }

    public function index() {
        $categories = $this->model->getAll();
        include "../views/categories/index.php";
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = $_POST['name'];
            $this->model->create($name);
            header("Location: index.php?controller=category&action=index");
        } else {
            include "../views/categories/create.php";
        }
    }

    public function edit() {
        $id = $_GET['id'];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = $_POST['name'];
            $this->model->update($id, $name);
            header("Location: index.php?controller=category&action=index");
        } else {
            $category = $this->model->getById($id);
            include "../views/categories/edit.php";
        }
    }

    public function delete() {
        $id = $_GET['id'];
        $this->model->delete($id);
        header("Location: index.php?controller=category&action=index");
    }
}
?>