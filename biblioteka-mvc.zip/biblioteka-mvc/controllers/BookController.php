<?php
require_once "../config/Database.php";
require_once "../models/Book.php";
require_once "../models/Category.php";

class BookController {
    private $bookModel;
    private $categoryModel;

    public function __construct() {
        $database = new Database();
        $db = $database->connect();
        $this->bookModel = new Book($db);
        $this->categoryModel = new Category($db);
    }

    public function index() {
        $books = $this->bookModel->getAll();
        include "../views/books/index.php";
    }

    public function create() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $year_published = $_POST['year_published'];
            $category_id = $_POST['category_id'];

            $this->bookModel->create($title, $author, $year_published, $category_id);
            header("Location: index.php?controller=book&action=index");
        } else {
            $categories = $this->categoryModel->getAll();
            include "../views/books/create.php";
        }
    }

    public function edit() {
        $id = $_GET['id'];

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $title = $_POST['title'];
            $author = $_POST['author'];
            $year_published = $_POST['year_published'];
            $category_id = $_POST['category_id'];

            $this->bookModel->update($id, $title, $author, $year_published, $category_id);
            header("Location: index.php?controller=book&action=index");
        } else {
            $book = $this->bookModel->getById($id);
            $categories = $this->categoryModel->getAll();
            include "../views/books/edit.php";
        }
    }

    public function delete() {
        $id = $_GET['id'];
        $this->bookModel->delete($id);
        header("Location: index.php?controller=book&action=index");
    }
}
?>