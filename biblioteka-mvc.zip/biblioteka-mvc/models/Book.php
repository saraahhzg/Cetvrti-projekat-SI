<?php
class Book {
    private $conn;
    private $table = "books";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $sql = "SELECT books.*, categories.name AS category_name
                FROM books
                INNER JOIN categories ON books.category_id = categories.id
                ORDER BY books.id DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt;
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM books WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function create($title, $author, $year_published, $category_id) {
        $sql = "INSERT INTO books (title, author, year_published, category_id)
                VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$title, $author, $year_published, $category_id]);
    }

    public function update($id, $title, $author, $year_published, $category_id) {
        $sql = "UPDATE books
                SET title = ?, author = ?, year_published = ?, category_id = ?
                WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute([$title, $author, $year_published, $category_id, $id]);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM books WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
?>